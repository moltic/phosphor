// ── core/render.js ───────────────────────────────────────────────────────────
// Render helpers (printLine / batch system) + banner rendering pipeline.

import { CONFIG, DEFAULT_BANNER } from './config.js';
import { loadPrefs } from './storage.js';

// ── DOM refs (safe to grab at module parse time — <script type="module"> is deferred) ──
export const outputEl     = document.getElementById('output');
export const scrollMoreEl = document.getElementById('scroll-more');
export const inputEl      = document.getElementById('cmd-input');
export const displayEl    = document.getElementById('input-display');
export const cursorEl     = document.getElementById('cursor');

// ── Active batch container ────────────────────────────────────────────────────
/** printLine writes here while a command is running; flushed atomically. */
let _batchEl = null;

// ── Typewriter / simulatedLatency support ────────────────────────────────────
/**
 * Cached prefs snapshot.  Populated lazily on first printLine call and kept
 * in sync by storage.js's onChanged listener so the delay reflects live changes.
 */
let _prefs = null;
loadPrefs().then(p => { _prefs = p; });

/**
 * Promise chain used to serialise typewriter rendering so concurrent printLine
 * calls outside a batch never interleave their character output.
 */
let _twChain = Promise.resolve();

/**
 * Return the per-character delay (ms) for the current prefs, or 0 for instant.
 * Returns 0 when:
 *   – simulatedLatency is off
 *   – reducedMotion is on
 *   – we are inside a batch (caller passes inBatch = true)
 * @param {boolean} inBatch
 * @returns {number}
 */
function _typewriterDelay(inBatch) {
  if (inBatch) return 0;
  if (!_prefs || !_prefs.simulatedLatency) return 0;
  if (_prefs.reducedMotion) return 0;
  const mode = _prefs.displayMode || 'classic';
  return CONFIG.TYPEWRITER_SPEEDS[mode] ?? CONFIG.TYPEWRITER_SPEEDS.classic;
}

/**
 * Reveal `text` character-by-character inside `span`, scrolling outputEl as we go.
 * Resolves once the last character has been painted.
 * @param {HTMLElement} span
 * @param {string} text
 * @param {number} charDelayMs
 * @returns {Promise<void>}
 */
async function _typewriterRender(span, text, charDelayMs) {
  for (const ch of text) {
    span.textContent += ch;
    outputEl.scrollTo({ top: outputEl.scrollHeight, behavior: 'instant' });
    await new Promise(r => setTimeout(r, charDelayMs));
  }
}

/** Timer handle for the auto-dismiss of the ▼ MORE ▼ hint. */
let _hintDismissTimer = null;

// ── Pager state ───────────────────────────────────────────────────────────────
/**
 * Non-null while a paginated response is waiting for user input.
 * @type {{ queue: ChildNode[], batchEl: HTMLElement } | null}
 */
let _pager = null;

/** True while a paginated command batch is waiting for Space / Enter. */
export function isPaging() { return _pager !== null; }

/**
 * Reveal the next screenful of a paginated batch.
 * Called from main.js when the user presses Space or Enter during paging.
 */
export function advancePage() {
  if (!_pager) return;
  const { queue, batchEl } = _pager;

  // Cancel any auto-dismiss timer so we can take over the hint element.
  if (_hintDismissTimer) { clearTimeout(_hintDismissTimer); _hintDismissTimer = null; }
  scrollMoreEl.classList.remove('fading', 'visible', 'pager-mode');

  const startHeight = outputEl.scrollHeight;
  while (queue.length > 0) {
    const el = queue.shift();
    batchEl.appendChild(el);
    // Stop once we've added roughly one screenful of new content.
    if (outputEl.scrollHeight - startHeight >= outputEl.clientHeight) break;
  }

  outputEl.scrollTo({ top: outputEl.scrollHeight, behavior: 'instant' });

  if (queue.length === 0) {
    // All pages revealed — exit pager mode.
    _pager = null;
    scrollMoreEl.textContent = '▼  MORE  ▼';
    updateScrollHint();
  } else {
    // More pages remain — show persistent press-any-key prompt.
    scrollMoreEl.textContent = '━━  MORE  (Space / Enter)  ━━';
    scrollMoreEl.classList.add('visible', 'pager-mode');
  }
}

/**
 * Cancel paging early, flushing all remaining queued lines immediately.
 * Called by beginBatch() so a new command always starts from a clean slate.
 */
function _cancelPager() {
  const { queue, batchEl } = _pager;
  for (const el of queue) batchEl.appendChild(el);
  _pager = null;
  if (_hintDismissTimer) { clearTimeout(_hintDismissTimer); _hintDismissTimer = null; }
  scrollMoreEl.classList.remove('pager-mode', 'visible', 'fading');
  scrollMoreEl.textContent = '▼  MORE  ▼';
  outputEl.scrollTo({ top: outputEl.scrollHeight, behavior: 'instant' });
}

// ============================================================
//  Print helpers
// ============================================================

/**
 * Append one line of text to the output area.
 * Safe to call with or without an active batch:
 *   • Inside a batch  → appended to the off-DOM _batchEl container instantly.
 *   • Outside a batch → appended to outputEl directly.  When simulatedLatency
 *     is enabled the text is revealed character-by-character (typewriter style)
 *     at a speed determined by the current displayMode pref, and the returned
 *     Promise resolves only when the last character has been painted.  Calls
 *     are serialised via an internal chain so rapid fire-and-forget invocations
 *     never interleave their output.
 *
 * @param {string} text
 * @param {string} [cls='line-out']
 * @returns {Promise<void>} Resolves immediately for batch/instant output,
 *                          or after the typewriter animation completes.
 */
export function printLine(text, cls = 'line-out') {
  const span = document.createElement('span');
  span.className = `line ${cls}`;

  if (_batchEl) {
    // Batch mode: fill instantly and return a resolved promise.
    span.textContent = text;
    _batchEl.appendChild(span);
    return Promise.resolve();
  }

  const charDelay = _typewriterDelay(false);

  if (charDelay <= 0) {
    // Instant mode (no latency simulation).
    span.textContent = text;
    outputEl.appendChild(span);
    outputEl.scrollTo({ top: outputEl.scrollHeight, behavior: 'instant' });
    return Promise.resolve();
  }

  // Typewriter mode: append the empty span now so layout is reserved, then
  // reveal characters one-by-one via the serialised _twChain.
  span.textContent = '';
  outputEl.appendChild(span);
  outputEl.scrollTo({ top: outputEl.scrollHeight, behavior: 'instant' });

  const p = _twChain.then(() => _typewriterRender(span, text, charDelay));
  // Swallow errors on the shared chain so one rejection doesn't block all
  // subsequent output.
  _twChain = p.catch(() => {});
  return p;
}

/** Append multiple lines with the same CSS class. */
export function printBlock(lines, cls = 'line-out') {
  lines.forEach(l => printLine(l, cls));
}

/** Insert one blank line. */
export function printBlank() { printLine(''); }

/** Insert a full-width horizontal rule made from a repeated character. */
export function printRule(char = '─', length = 58) {
  printLine(char.repeat(length), 'line-sep');
}

/**
 * Append a pre-rendered neon banner (DOM nodes from buildBannerNodes) to #output.
 * @param {DocumentFragment} nodes – generated by buildBannerNodes()
 */
export function printBannerNodes(nodes) {
  const pre = document.createElement('pre');
  pre.className = 'banner-output';
  pre.appendChild(nodes);
  if (_batchEl) {
    _batchEl.appendChild(pre);
  } else {
    outputEl.appendChild(pre);
    outputEl.scrollTo({ top: outputEl.scrollHeight, behavior: 'instant' });
  }
}

/** Wipe the terminal output area.  Storage is untouched. */
export function clearScreen() {
  const termEl = document.getElementById('terminal');
  termEl.classList.add('crt-wipe');
  setTimeout(() => termEl.classList.remove('crt-wipe'), CONFIG.CRT_WIPE_MS);
  outputEl.innerHTML = '';
}

/**
 * Start collecting printLine output into an off-DOM batch container.
 * Call before running a command so all its lines are batched together.
 */
export function beginBatch() {
  // If a previous command is still mid-page, flush all remaining content now.
  if (_pager) _cancelPager();
  _batchEl = document.createElement('div');
  _batchEl.className = 'cmd-output-block';
}

/**
 * Flush the current batch to #output in one DOM insertion so the
 * aria-live="polite" region announces the full response once.
 */
export function endBatch() {
  if (_batchEl) {
    if (_batchEl.hasChildNodes()) {
      // Measure how much height this batch adds so we can decide whether to page.
      const heightBefore = outputEl.scrollHeight;
      outputEl.appendChild(_batchEl);
      const batchHeight = outputEl.scrollHeight - heightBefore;

      // If the new batch is taller than one viewport, activate the pager.
      if (outputEl.clientHeight > 0 && batchHeight > outputEl.clientHeight) {
        // Pull all children out of the (now-live) batch element into the queue.
        const queue = [..._batchEl.childNodes];
        _batchEl.innerHTML = '';
        _pager = { queue, batchEl: _batchEl };
        _batchEl = null;
        advancePage(); // shows first screenful + sets the hint
        return;
      }

      outputEl.scrollTo({ top: outputEl.scrollHeight, behavior: 'instant' });
    }
    _batchEl = null;
  }
  updateScrollHint();
}

/** Show/hide the ▼ MORE ▼ hint based on whether #output has content below the fold.
 *  When shown, the hint auto-dismisses after 2.5 s with a fade-out so it doesn't
 *  linger while the user types their next command.
 *  No-op while the pager is active (pager controls the hint element directly). */
export function updateScrollHint() {
  if (_pager) return; // pager owns the hint while paginating
  const hasOverflow = outputEl.scrollHeight > outputEl.clientHeight;
  const atBottom    = outputEl.scrollTop + outputEl.clientHeight >= outputEl.scrollHeight - 4;
  const shouldShow  = hasOverflow && !atBottom;

  // Cancel any in-flight auto-dismiss before re-evaluating state.
  if (_hintDismissTimer) { clearTimeout(_hintDismissTimer); _hintDismissTimer = null; }
  scrollMoreEl.classList.remove('fading');
  scrollMoreEl.classList.toggle('visible', shouldShow);

  if (shouldShow) {
    // After 2.5 s, start a 0.5 s opacity fade, then fully hide.
    _hintDismissTimer = setTimeout(() => {
      scrollMoreEl.classList.add('fading');
      _hintDismissTimer = setTimeout(() => {
        scrollMoreEl.classList.remove('visible', 'fading');
        _hintDismissTimer = null;
      }, 500);
    }, 2500);
  }
}

/** Return a reference to the currently-active batch element, or null. */
export function getBatchEl() { return _batchEl; }

// ── Input mirror helpers ──────────────────────────────────────────────────────

/**
 * Set the hidden <input> value and immediately sync the visible display.
 * Always use this instead of writing inputEl.value directly.
 */
export function setInput(val) {
  inputEl.value = val;
  syncDisplay();
}

/** Copy the real <input> value into the visible #input-display span. */
export function syncDisplay() {
  displayEl.textContent = inputEl.value;
}

// ── Word-wrap utility ─────────────────────────────────────────────────────────

/**
 * Word-wrap `text` so no line exceeds `maxWidth` characters.
 * Returns an array of lines.
 */
export function wrapWords(text, maxWidth) {
  const words = text.split(' ');
  const lines = [];
  let current = '';
  for (const word of words) {
    if (!current) {
      current = word;
    } else if (current.length + 1 + word.length <= maxWidth) {
      current += ' ' + word;
    } else {
      lines.push(current);
      current = word;
    }
  }
  if (current) lines.push(current);
  return lines;
}

// ============================================================
//  Banner rendering pipeline
// ============================================================

// Visual scale for the header banner after auto-fit measurement.
const BANNER_FIT_SCALE         = 0.86;
const BANNER_FIT_MAX_CHARS     = 140;
const BANNER_FIT_MAX_PX        = 32;
// Maximum banner height expressed as a fraction of the viewport height.
// Prevents short greetings from inflating the font until they tower over the layout.
const BANNER_FIT_MAX_HEIGHT_VH = 0.25;
// Must match the CSS line-height on #ascii-art (currently 1.02).
const BANNER_LINE_HEIGHT       = 1.02;

// Legacy 6-row banner font (Unicode).
const LEGACY_BANNER_FONT = {
  ' ': ['   ', '   ', '   ', '   ', '   ', '   '],
  '?': ['█████╗ ', '╚═══██╗', '  ██╔╝ ', ' ██╔╝  ', ' ██║   ', ' ╚═╝   '],
  '-': ['      ', '      ', '█████╗', '╚════╝', '      ', '      '],
  ',': ['    ', '    ', '    ', '    ', '██╗ ', '╚██║'],
  '.': ['   ', '   ', '   ', '   ', '██╗', '╚═╝'],
  ':': ['   ', '██╗', '╚═╝', '██╗', '╚═╝', '   '],
  'a': ['        ', ' █████╗ ', '██╔══██╗', '███████║', '██╔══██║', '╚══════╝'],
  'b': ['██╗     ', '██║     ', '██████╗ ', '██╔══██╗', '██████╔╝', '╚═════╝ '],
  'c': ['        ', ' ██████╗', '██╔════╝', '██║     ', '╚██████╗', ' ╚═════╝'],
  'd': ['     ██╗', '     ██║', ' ██████║', '██╔══██║', '╚██████║', ' ╚═════╝'],
  'e': ['        ', ' █████╗ ', '██╔═══╝ ', '█████╗  ', '██╔══╝  ', '╚█████╗ '],
  'f': [' ████╗  ', '██╔══╝  ', '███████╗', '██╔════╝', '██║     ', '╚═╝     '],
  'g': ['        ', ' █████╗ ', '██╔══██╗', '╚██████╗', '     ██║', ' ███████'],
  'h': ['██╗     ', '██║     ', '███████╗', '██╔══██║', '██║  ██║', '╚═╝  ╚═╝'],
  'i': ['██╗', '╚═╝', '██╗', '██║', '██║', '╚═╝'],
  'j': ['  ██╗', '  ╚═╝', '  ██╗', '  ██║', '██╔╝ ', '╚═╝  '],
  'k': ['██╗  ██╗', '██║ ██╔╝', '█████╔╝ ', '██╔═██╗ ', '██║  ██╗', '╚═╝  ╚═╝'],
  'l': ['███╗ ', '╚██║ ', ' ██║ ', ' ██║ ', '████╗', '╚═══╝'],
  'm': ['           ', '███╗   ███╗', '████╗ ████║', '██╔████╔██║', '██║╚██╔╝██║', '╚═╝ ╚═╝ ╚═╝'],
  'n': ['        ', '███████╗', '██╔══██║', '██║  ██║', '██║  ██║', '╚═╝  ╚═╝'],
  'o': ['        ', ' █████╗ ', '██╔══██╗', '██║  ██║', '╚█████╔╝', ' ╚════╝ '],
  'p': ['        ', '██████╗ ', '██╔══██╗', '██████╔╝', '██╔════╝', '██║     '],
  'q': ['        ', ' █████╗ ', '██╔══██╗', '██║  ██╗', '╚█████╔╝', '     ██╗'],
  'r': ['        ', '██████╗ ', '██╔══██╗', '██║  ╚═╝', '██║     ', '╚═╝     '],
  's': ['        ', ' ██████╗', '██╔════╝', '╚█████╗ ', ' ╚═══██╗', '██████╔╝'],
  't': ['   ██╗  ', '███████╗', '╚══╝██║ ', '   ██║  ', '   ████╗', '   ╚═══╝'],
  'u': ['         ', '██╗   ██╗', '██║   ██║', '██║   ██║', '╚██████╔╝', ' ╚═════╝ '],
  'v': ['        ', '██╗  ██╗', '██║  ██║', '╚██╗██╔╝', ' ╚███╔╝ ', '  ╚══╝  '],
  'w': ['           ', '██╗    ██╗ ', '██║ ██╗ ██║', '╚██╗███╔╝  ', ' ╚████╔╝   ', '  ╚═════╝  '],
  'x': ['        ', '██╗  ██╗', '╚██╗██╔╝', ' ╚███╔╝ ', ' ██╔██╗ ', '╚═╝  ╚═╝'],
  'y': ['        ', '██╗  ██╗', '╚██╗██╔╝', ' ╚████╔╝', '  ╚██╔╝ ', '   ██║  '],
  'z': ['        ', '███████╗', '╚══███╔╝', '  ███╔╝ ', '███████╗', '╚══════╝'],
  '0': [' ██████╗', '██╔═████╗', '██║██╔██║', '████╔╝██║', '╚██████╔╝', ' ╚═════╝ '],
  '1': [' ██╗', '███║', '╚██║', ' ██║', ' ██║', ' ╚═╝'],
  '2': ['██████╗ ', '╚════██╗', ' █████╔╝', '██╔═══╝ ', '███████╗', '╚══════╝'],
  '3': ['██████╗ ', '╚════██╗', ' █████╔╝', ' ╚═══██╗', '██████╔╝', '╚═════╝ '],
  '4': ['██╗  ██╗', '██║  ██║', '███████║', '╚════██║', '     ██║', '     ╚═╝'],
  '5': ['███████╗', '██╔════╝', '██████╗ ', '╚════██╗', '██████╔╝', '╚═════╝ '],
  '6': [' ██████╗', '██╔════╝', '██████╗ ', '██╔══██╗', '╚██████╔╝', ' ╚═════╝ '],
  '7': ['███████╗', '╚════██║', '    ██╔╝', '   ██╔╝ ', '   ██║  ', '   ╚═╝  '],
  '8': [' █████╗ ', '██╔══██╗', '╚█████╔╝', '██╔══██╗', '╚█████╔╝', ' ╚════╝ '],
  '9': [' █████╗ ', '██╔══██╗', '╚██████║', ' ╚═══██║', ' █████╔╝', ' ╚════╝ '],
  'A': [' █████╗ ', '██╔══██╗', '███████║', '██╔══██║', '██║  ██║', '╚═╝  ╚═╝'],
  'B': ['██████╗ ', '██╔══██╗', '██████╔╝', '██╔══██╗', '██████╔╝', '╚═════╝ '],
  'C': [' ██████╗', '██╔════╝', '██║     ', '██║     ', '╚██████╗', ' ╚═════╝'],
  'D': ['██████╗ ', '██╔══██╗', '██║  ██║', '██║  ██║', '██████╔╝', '╚═════╝ '],
  'E': ['███████╗', '██╔════╝', '██████╗ ', '██╔═══╝ ', '███████╗', '╚══════╝'],
  'F': ['███████╗', '██╔════╝', '██████╗ ', '██╔═══╝ ', '██║     ', '╚═╝     '],
  'G': [' ██████╗', '██╔════╝', '██║  ███╗', '██║   ██║', '╚██████╔╝', ' ╚═════╝ '],
  'H': ['██╗  ██╗', '██║  ██║', '███████║', '██╔══██║', '██║  ██║', '╚═╝  ╚═╝'],
  'I': ['██████╗', '╚══██╔╝', '   ██║ ', '   ██║ ', '██████╗', '╚═════╝'],
  'J': ['     ██╗', '     ██║', '     ██║', '██   ██║', '╚█████╔╝', ' ╚════╝ '],
  'K': ['██╗  ██╗', '██║ ██╔╝', '█████╔╝ ', '██╔═██╗ ', '██║  ██╗', '╚═╝  ╚═╝'],
  'L': ['██╗     ', '██║     ', '██║     ', '██║     ', '███████╗', '╚══════╝'],
  'M': ['███╗   ███╗', '████╗ ████║', '██╔████╔██║', '██║╚██╔╝██║', '██║ ╚═╝ ██║', '╚═╝     ╚═╝'],
  'N': ['███╗   ██╗', '████╗  ██║', '██╔██╗ ██║', '██║╚██╗██║', '██║ ╚████║', '╚═╝  ╚═══╝'],
  'O': [' ██████╗', '██╔═══██╗', '██║   ██║', '██║   ██║', '╚██████╔╝', ' ╚═════╝ '],
  'P': ['██████╗ ', '██╔══██╗', '██████╔╝', '██╔═══╝ ', '██║     ', '╚═╝     '],
  'Q': [' ██████╗ ', '██╔═══██╗', '██║   ██║', '██║▄▄ ██║', '╚█████╔╝ ', '     ╚██╗'],
  'R': ['██████╗ ', '██╔══██╗', '██████╔╝', '██╔══██╗', '██║  ██║', '╚═╝  ╚═╝'],
  'S': [' ██████╗', '██╔════╝', '╚█████╗ ', ' ╚═══██╗', '██████╔╝', '╚═════╝ '],
  'T': ['████████╗', '╚══██╔══╝', '   ██║   ', '   ██║   ', '   ██║   ', '   ╚═╝   '],
  'U': ['██╗   ██╗', '██║   ██║', '██║   ██║', '██║   ██║', '╚██████╔╝', ' ╚═════╝ '],
  'V': ['██╗   ██╗', '██║   ██║', '██║   ██║', '╚██╗ ██╔╝', ' ╚████╔╝ ', '  ╚═══╝  '],
  'W': ['██╗    ██╗', '██║    ██║', '██║ █╗ ██║', '██║███╗██║', '╚███╔███╔╝', ' ╚══╝╚══╝ '],
  'X': ['██╗  ██╗', '╚██╗██╔╝', ' ╚███╔╝ ', ' ██╔██╗ ', '██╔╝ ██╗', '╚═╝  ╚═╝'],
  'Y': ['██╗   ██╗', '╚██╗ ██╔╝', ' ╚████╔╝ ', '  ╚██╔╝  ', '   ██║   ', '   ╚═╝   '],
  'Z': ['███████╗', '╚══███╔╝', '  ███╔╝ ', ' ███╔╝  ', '███████╗', '╚══════╝'],
};

function renderLegacyBannerText(text) {
  const normalized = String(text || DEFAULT_BANNER).replace(/\r/g, '').trim();
  if (!normalized) return '';

  const chars = [...normalized];
  const rows = 6;
  const out = [];
  const LOWER_ASCENDERS = new Set(['b', 'd', 'f', 'h', 'i', 'j', 'k', 'l', 't']);

  function glyphRowsForChar(ch) {
    const isLower = ch >= 'a' && ch <= 'z';
    const upper = isLower ? ch.toUpperCase() : ch;
    const key = (isLower && LEGACY_BANNER_FONT[ch])
      ? ch
      : (LEGACY_BANNER_FONT[upper] ? upper : (LEGACY_BANNER_FONT[ch] ? ch : '?'));
    const glyph = LEGACY_BANNER_FONT[key];
    const width = Math.max(0, ...glyph.map(r => r.length));

    if (isLower && key === ch) {
      return glyph.map(r => String(r || '').padEnd(width, ' '));
    }
    if (!isLower) {
      return glyph.map(r => String(r || '').padEnd(width, ' '));
    }

    const keepAscender = LOWER_ASCENDERS.has(ch);
    const row0 = keepAscender
      ? String(glyph[0] || '').padEnd(width, ' ')
      : ' '.repeat(width);
    const body = glyph.slice(1).map(r => String(r || '').padEnd(width, ' '));
    return [row0, ...body].slice(0, rows);
  }

  for (let y = 0; y < rows; y += 1) {
    const line = chars.map(ch => {
      const glyphRows = glyphRowsForChar(ch);
      return glyphRows[y] || '';
    }).join(' ');
    out.push(line.replace(/\s+$/g, ''));
  }

  return out.join('\n');
}

function computeDistanceFromEmpty(lines) {
  const height = lines.length;
  const width  = Math.max(0, ...lines.map(line => line.length));
  const grid   = Array.from({ length: height }, (_, y) =>
    Array.from({ length: width }, (_, x) => (lines[y][x] || ' ') !== ' ')
  );

  if (!height || !width) return { grid, dist: [] };

  const padH = height + 2;
  const padW = width  + 2;
  const occ  = Array.from({ length: padH }, () => Array(padW).fill(false));
  for (let y = 0; y < height; y += 1)
    for (let x = 0; x < width; x += 1)
      occ[y + 1][x + 1] = grid[y][x];

  const distPad = Array.from({ length: padH }, () => Array(padW).fill(Infinity));
  const q = [];
  let qHead = 0;
  for (let y = 0; y < padH; y += 1)
    for (let x = 0; x < padW; x += 1)
      if (!occ[y][x]) { distPad[y][x] = 0; q.push([x, y]); }

  const dirs = [[1,0],[-1,0],[0,1],[0,-1]];
  while (qHead < q.length) {
    const [x, y] = q[qHead++];
    const nextDist = distPad[y][x] + 1;
    for (const [dx, dy] of dirs) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= padW || ny >= padH) continue;
      if (nextDist < distPad[ny][nx]) { distPad[ny][nx] = nextDist; q.push([nx, ny]); }
    }
  }

  const dist = Array.from({ length: height }, (_, y) =>
    Array.from({ length: width }, (_, x) => distPad[y + 1][x + 1])
  );
  return { grid, dist };
}

function bannerCellClass(distance, x, y) {
  if (distance <= 1) return 'b-rim';
  if (distance === 2) return 'b-edge';
  if (distance === 3) return 'b-mid';
  if (distance >= 5 && (x + y) % 7 === 0) return 'b-node';
  return 'b-core';
}

/** Build the neon banner DOM nodes from a raw multi-line ASCII-art string. */
export function buildBannerNodes(raw, { preserveGlyphs = true } = {}) {
  const lines = String(raw || '').replace(/\r/g, '').split('\n');
  while (lines.length && lines[lines.length - 1] === '') lines.pop();
  const fragment = document.createDocumentFragment();
  if (!lines.length) return fragment;

  const { grid, dist } = computeDistanceFromEmpty(lines);
  const height = grid.length;
  const width  = Math.max(0, ...lines.map(line => line.length));

  lines.forEach((line, y) => {
    for (let x = 0; x < width; x += 1) {
      const span = document.createElement('span');
      if (!(grid[y]?.[x])) {
        span.className = 'b-cell b-empty';
        span.innerHTML = '&nbsp;';
      } else {
        span.className = `b-cell ${bannerCellClass(dist[y][x], x, y)}`;
        span.textContent = preserveGlyphs ? (line[x] || ' ') : '█';
      }
      fragment.appendChild(span);
    }
    if (y < height - 1) {
      fragment.appendChild(document.createTextNode('\n'));
    }
  });

  return fragment;
}

/** Render banner text into a DOM fragment for command output. */
export async function renderBanner(text) {
  const normalized = String(text || DEFAULT_BANNER).replace(/\r/g, '').trim();
  const bannerText = normalized || DEFAULT_BANNER;
  const raw = renderLegacyBannerText(bannerText);
  return { kind: 'html', value: buildBannerNodes(raw, { preserveGlyphs: false }) };
}

/** Render banner text for the header #ascii-art element. */
export function renderHeaderBanner(text) {
  const normalized = String(text || DEFAULT_BANNER).replace(/\r/g, '').trim();
  const bannerText = normalized || DEFAULT_BANNER;
  const raw = renderLegacyBannerText(bannerText);
  return { kind: 'html', value: buildBannerNodes(raw, { preserveGlyphs: true }) };
}

/** Set the #ascii-art element's content (DOM node or plain text). */
export function setAsciiArt(el, textOrNode, { asHtml = true } = {}) {
  if (asHtml) {
    el.innerHTML = '';
    if (textOrNode) {
      el.appendChild(textOrNode);
    }
  } else {
    el.textContent = textOrNode || '';
  }
}

/**
 * Scale #ascii-art font-size so the longest line fills ~86% of its container.
 */
export async function fitBanner(el) {
  await document.fonts.ready;
  const lines  = el.textContent.split('\n');
  const maxLen = Math.max(...lines.map(l => l.length));
  if (!maxLen) return;

  const fitLen = Math.min(maxLen, BANNER_FIT_MAX_CHARS);

  const probe = document.createElement('pre');
  probe.style.cssText =
    'position:absolute;top:-9999px;left:-9999px;visibility:hidden;' +
    'margin:0;padding:0;border:0;font:inherit';
  probe.textContent = '█'.repeat(fitLen);
  document.body.appendChild(probe);
  const probeW = probe.getBoundingClientRect().width;
  const refPx  = parseFloat(getComputedStyle(probe).fontSize);
  document.body.removeChild(probe);
  if (!probeW || !refPx) return;

  const available = Math.max(0, el.parentElement.clientWidth - 18);
  // Correct for the probe cap: if the actual banner is wider than BANNER_FIT_MAX_CHARS,
  // the probe under-represents the real width and would produce a font that is too large.
  // Multiplying by (fitLen / maxLen) scales the result back to the true content width.
  const widthPx = (available * BANNER_FIT_SCALE / probeW) * refPx * (fitLen / maxLen);

  // Height guard: clamp so the full banner never exceeds BANNER_FIT_MAX_HEIGHT_VH
  // of the viewport height, regardless of how few characters the greeting has.
  const numRows     = lines.length || 6;
  const maxHeightPx = window.innerHeight * BANNER_FIT_MAX_HEIGHT_VH;
  const heightPx    = maxHeightPx / (numRows * BANNER_LINE_HEIGHT);

  const idealPx = Math.min(widthPx, heightPx);
  el.style.fontSize = Math.min(Math.max(Math.round(idealPx), 6), BANNER_FIT_MAX_PX) + 'px';

  // Safety net: if the content still overflows after font-size is set (e.g. due to
  // font metrics rounding), shrink further until it fits.
  if (el.scrollWidth > el.parentElement.clientWidth) {
    const overflowRatio = el.parentElement.clientWidth / el.scrollWidth;
    const currentPx = parseFloat(el.style.fontSize) || idealPx;
    el.style.fontSize = Math.max(Math.floor(currentPx * overflowRatio), 6) + 'px';
  }
}

/**
 * Measure and set CSS custom properties for banner cell widths.
 * Called after font-size changes so neon columns stay aligned.
 */
export async function updateBannerMetrics() {
  try { await document.fonts.ready; } catch { /* ignore */ }
  const root   = document.documentElement;
  const GLYPHS = ['█', '╗', '╔', '╝', '╚', '═', '║'];

  function measureMaxWidthFor(preEl) {
    const spans  = GLYPHS.map(g => {
      const s = document.createElement('span');
      s.textContent = g;
      preEl.appendChild(s);
      return s;
    });
    const widths = spans.map(s => s.getBoundingClientRect().width);
    return Math.max(0, ...widths);
  }

  // Banner command output
  {
    const pre = document.createElement('pre');
    pre.className  = 'banner-output';
    pre.style.cssText =
      'position:absolute;top:-9999px;left:-9999px;visibility:hidden;' +
      'margin:0;padding:0;border:0;white-space:pre;';
    document.body.appendChild(pre);
    const maxW = measureMaxWidthFor(pre);
    document.body.removeChild(pre);
    if (maxW) root.style.setProperty('--banner-output-cell-w', maxW + 'px');
  }

  // Header banner
  {
    const header = document.getElementById('ascii-art');
    if (header) {
      const cs  = getComputedStyle(header);
      const pre = document.createElement('pre');
      pre.style.cssText =
        'position:absolute;top:-9999px;left:-9999px;visibility:hidden;' +
        'margin:0;padding:0;border:0;white-space:pre;';
      pre.style.fontFamily           = cs.fontFamily;
      pre.style.fontSize             = cs.fontSize;
      pre.style.fontWeight           = cs.fontWeight;
      pre.style.fontStyle            = cs.fontStyle;
      pre.style.letterSpacing        = cs.letterSpacing;
      pre.style.fontKerning          = 'none';
      pre.style.fontVariantLigatures = 'none';
      pre.style.fontFeatureSettings  = '"liga" 0, "kern" 0';
      document.body.appendChild(pre);
      const maxW = measureMaxWidthFor(pre);
      document.body.removeChild(pre);
      if (maxW) root.style.setProperty('--banner-header-cell-w', maxW + 'px');
    }
  }
}
